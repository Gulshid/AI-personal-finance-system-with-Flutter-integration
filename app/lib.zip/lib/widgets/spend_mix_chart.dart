import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../models/models.dart';

/// Donut chart breaking down a user's spend mix by category, with a
/// scrollable legend. Sorted largest-first so the legend reads like a
/// ranked list, not a random jumble.
class SpendMixChart extends StatefulWidget {
  final Map<String, double> spendMix;
  const SpendMixChart({super.key, required this.spendMix});

  @override
  State<SpendMixChart> createState() => _SpendMixChartState();
}

class _SpendMixChartState extends State<SpendMixChart> {
  int? _touchedIndex;

  @override
  Widget build(BuildContext context) {
    final entries = widget.spendMix.entries
        .where((e) => e.value > 0)
        .toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    if (entries.isEmpty) {
      return const SizedBox(
        height: 160,
        child: Center(child: Text('No spend-mix data yet.')),
      );
    }

    return Column(
      children: [
        SizedBox(
          height: 190,
          child: Row(
            children: [
              Expanded(
                flex: 5,
                child: PieChart(
                  PieChartData(
                    sectionsSpace: 3,
                    centerSpaceRadius: 46,
                    pieTouchData: PieTouchData(
                      touchCallback: (event, response) {
                        setState(() {
                          _touchedIndex = response?.touchedSection?.touchedSectionIndex;
                        });
                      },
                    ),
                    sections: List.generate(entries.length, (i) {
                      final e = entries[i];
                      final style = CategoryStyle.of(e.key);
                      final isTouched = i == _touchedIndex;
                      return PieChartSectionData(
                        value: e.value,
                        color: style.color,
                        radius: isTouched ? 46 : 40,
                        showTitle: false,
                      );
                    }),
                  ),
                ),
              ),
              Expanded(
                flex: 5,
                child: ListView.builder(
                  padding: EdgeInsets.zero,
                  itemCount: entries.length,
                  itemBuilder: (context, i) {
                    final e = entries[i];
                    final style = CategoryStyle.of(e.key);
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(color: style.color, shape: BoxShape.circle),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              e.key,
                              style: const TextStyle(fontSize: 12.5, color: AppTheme.textPrimary),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Text(
                            '${(e.value * 100).toStringAsFixed(0)}%',
                            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
