import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../models/models.dart';
import '../services/api_exception.dart';
import '../services/finance_ai_service.dart';
import '../widgets/common_widgets.dart';
import '../widgets/persona_card.dart';
import '../widgets/recommendation_card.dart';
import '../widgets/spend_mix_chart.dart';

class DashboardScreen extends StatefulWidget {
  final int userId;
  final FinanceAiService api;
  const DashboardScreen({super.key, required this.userId, required this.api});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<_DashboardData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_DashboardData> _load() async {
    // Fetch cluster + recommendations together; if either fails the whole
    // screen shows the error state with a retry button.
    final results = await Future.wait([
      widget.api.getUserCluster(widget.userId),
      widget.api.getUserRecommendations(widget.userId),
    ]);
    return _DashboardData(
      cluster: results[0] as ClusterProfile,
      recommendations: results[1] as List<RecommendationItem>,
    );
  }

  void _retry() => setState(() => _future = _load());

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => _retry(),
      child: FutureBuilder<_DashboardData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingView(message: 'Loading your dashboard...');
          }
          if (snapshot.hasError) {
            final message =
                snapshot.error is ApiException ? snapshot.error.toString() : 'Unexpected error occurred.';
            return ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.6,
                  child: ErrorView(message: message, onRetry: _retry),
                ),
              ],
            );
          }

          final data = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              PersonaCard(profile: data.cluster),
              const SizedBox(height: 24),
              const SectionHeader(title: 'Spend mix'),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.04),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: SpendMixChart(spendMix: data.cluster.spendMix),
              ),
              const SizedBox(height: 24),
              const SectionHeader(title: 'Top insights'),
              const SizedBox(height: 12),
              if (data.recommendations.isEmpty)
                const EmptyStateView(
                  icon: Icons.check_circle_rounded,
                  message: 'No unusual spending patterns detected right now.',
                )
              else
                ...data.recommendations.take(3).map(
                      (r) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: RecommendationCard(item: r),
                      ),
                    ),
            ],
          );
        },
      ),
    );
  }
}

class _DashboardData {
  final ClusterProfile cluster;
  final List<RecommendationItem> recommendations;
  _DashboardData({required this.cluster, required this.recommendations});
}
