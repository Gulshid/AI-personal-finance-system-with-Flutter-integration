import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_exception.dart';
import '../services/finance_ai_service.dart';
import '../widgets/common_widgets.dart';
import '../widgets/recommendation_card.dart';

class RecommendationsScreen extends StatefulWidget {
  final int userId;
  final FinanceAiService api;
  const RecommendationsScreen({super.key, required this.userId, required this.api});

  @override
  State<RecommendationsScreen> createState() => _RecommendationsScreenState();
}

class _RecommendationsScreenState extends State<RecommendationsScreen> {
  late Future<List<RecommendationItem>> _future;

  @override
  void initState() {
    super.initState();
    _future = widget.api.getUserRecommendations(widget.userId);
  }

  void _retry() => setState(() => _future = widget.api.getUserRecommendations(widget.userId));

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => _retry(),
      child: FutureBuilder<List<RecommendationItem>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingView(message: 'Generating insights...');
          }
          if (snapshot.hasError) {
            final message =
                snapshot.error is ApiException ? snapshot.error.toString() : 'Unexpected error occurred.';
            return ListView(children: [
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.6,
                child: ErrorView(message: message, onRetry: _retry),
              ),
            ]);
          }

          final items = snapshot.data!;
          if (items.isEmpty) {
            return ListView(children: const [
              SizedBox(
                height: 400,
                child: EmptyStateView(
                  icon: Icons.check_circle_rounded,
                  message: 'No unusual spending patterns detected right now.\nCheck back after your next few transactions.',
                ),
              ),
            ]);
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, i) => RecommendationCard(item: items[i]),
          );
        },
      ),
    );
  }
}
